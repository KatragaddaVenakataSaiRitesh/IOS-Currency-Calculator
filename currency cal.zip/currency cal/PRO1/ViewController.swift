//
//  ViewController.swift
//  PRO1
//
//  Created by Ritesh Chowdary on 3/3/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var cadAmount: UITextField!
    @IBOutlet weak var usdAmount: UITextField!
    
    @IBAction func convert(_ sender: Any) {
        if let cad = cadAmount.text, !cad.isEmpty{
                let cads: Double = Double(cad)!
                let usd = cads * 1.34
            usdAmount.text = String(usd)
            message.text = ""
                
            }else if let usd = usdAmount.text, !usd.isEmpty{
                let usds: Double = Double(usd)!
                    let cad = usds / 1.34
                cadAmount.text = String(cad)
                message.text = ""
            }
            else {
                message.text = "PLease enter the cad amount"
            }
            
        }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

